let menu = document.querySelector('#menu-icon');
var nav = document.querySelector('.navlist');


menu.onclick = () => {

    menu.classList.toggle('bx-x');
    nav.classList.toggle('open');
}

